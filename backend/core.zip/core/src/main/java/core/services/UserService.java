package core.services;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import core.entities.CompanyDictionaryEntity;
import core.entities.RoleDictionaryEntity;
import core.entities.UserEntity;
import core.repository.CompanyDictionaryRepository;
import core.repository.RoleDictionaryRepository;
import core.repository.UserRepository;
import core.vo.UserVO;
@Service
public class UserService {
    private static UserRepository userRepository = null;
            private final RoleDictionaryRepository roleDictionaryRepository;
            private final CompanyDictionaryRepository companyDictionaryRepository;
            private final PasswordEncoder passwordEncoder;
            
            public UserService(UserRepository userRepository,
            RoleDictionaryRepository roleDictionaryRepository,
            CompanyDictionaryRepository companyDictionaryRepository, PasswordEncoder passwordEncoder) {
                UserService.userRepository = userRepository;
            this.roleDictionaryRepository = roleDictionaryRepository;
            this.companyDictionaryRepository = companyDictionaryRepository;
            this.passwordEncoder = passwordEncoder;
        }
        // Unos korisnika
        public UserVO createUser(UserVO userVO, Long currentCompanyId) {
            // Provjera da li korisničko ime već postoji
            Optional<UserEntity> existingUser = userRepository.findByUsername(userVO.getUsername());
            if (existingUser.isPresent()) {
                throw new IllegalArgumentException("Korisničko ime već postoji!");
            }
    
            UserEntity userEntity = new UserEntity();
            userEntity.setUsername(userVO.getUsername());
            userEntity.setPasswordHash(passwordEncoder.encode(userVO.getPassword())); // Hashiranje lozinke
    
            // Set role
            if (userVO.getRoleId() == null) {
                throw new IllegalArgumentException("Role ID is required!");
            }
            RoleDictionaryEntity role = roleDictionaryRepository.findById(userVO.getRoleId())
                    .orElseThrow(() -> new IllegalArgumentException("Role not found for ID: " + userVO.getRoleId()));
            userEntity.setRole(role);
    
            // Set company from the currently logged-in user
            CompanyDictionaryEntity company = companyDictionaryRepository.findById(currentCompanyId)
                    .orElseThrow(() -> new IllegalArgumentException("Company not found for ID: " + currentCompanyId));
            userEntity.setCompany(company);
    
            UserEntity savedUser = userRepository.save(userEntity);
            return new UserVO(
                savedUser.getUserId(),
                savedUser.getUsername(),
                null, // don't return the password
                savedUser.getRole().getRoleId(),
                savedUser.getRole().getRoleName() // Include role name
            );
        }
    
        // Get a user by ID (example)
        public UserVO getUserById(Long userId) {
            UserEntity userEntity = userRepository.findById(userId)
                    .orElseThrow(() -> new IllegalArgumentException("User not found for ID: " + userId));
            return new UserVO(
                userEntity.getUserId(),
                userEntity.getUsername(),
                null, // don't return the password
                userEntity.getRole().getRoleId(),
                userEntity.getRole().getRoleName() // Include role name
            );
        }
        public static List<UserVO> getAllUsers() {
            return userRepository.findAll().stream()
            .map(userEntity -> new UserVO(
                userEntity.getUserId(),
                userEntity.getUsername(),
                null, // do not return password
                userEntity.getRole().getRoleId(),
                userEntity.getRole().getRoleName() // fetch roleName here
            ))
            .collect(Collectors.toList());
    }
    public UserVO getUserByUsername(String username) {
        UserEntity userEntity = userRepository.findByUsername(username)
            .orElseThrow(() -> new IllegalArgumentException("User not found for username: " + username));
        return new UserVO(
            userEntity.getUserId(),
            userEntity.getUsername(),
            null, // Nikad ne vraćajte lozinku
            userEntity.getRole().getRoleId(),
            userEntity.getRole().getRoleName() // Ako RoleDictionaryEntity ima getRoleName()
        );
    }
}
