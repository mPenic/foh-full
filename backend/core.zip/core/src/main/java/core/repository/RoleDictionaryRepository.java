package core.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import core.entities.RoleDictionaryEntity;

@Repository
public interface RoleDictionaryRepository extends JpaRepository<RoleDictionaryEntity, Long> {
    // Prilagođene metode ako su potrebne
}
