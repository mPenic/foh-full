package core.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import core.entities.CompanyDictionaryEntity;

@Repository
public interface CompanyDictionaryRepository extends JpaRepository<CompanyDictionaryEntity, Long> {
    // Additional custom queries can be defined here if needed
}