package core.controller;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import core.entities.UserEntity;
import core.repository.UserRepository;

@RestController
@RequestMapping("/api") // Ovo mapira osnovni URL /api
public class UserController {

    private final UserRepository userRepository;

    public UserController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @GetMapping("/check-user") // Mapa ruta /api/check-user
    public ResponseEntity<?> checkUser(@RequestParam String username) {
        UserEntity user = userRepository.findByUsername(username).orElse(null);
        if (user == null) {
            return ResponseEntity.status(404).body("User not found");
        }
        return ResponseEntity.ok("User found: " + user.getUsername());
    }
}
